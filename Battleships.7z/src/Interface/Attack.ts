import { Battleship } from "../GameObjects/Battleships"
import { GameObject } from "../GameObjects/GameObject"

interface Attack {
    dmg: number;
    attack(target:{}): void;
    }

export { Attack }
