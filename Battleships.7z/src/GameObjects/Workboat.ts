import { GameObject } from "./GameObject"
import { Repair } from "../Interface/Repair";

class workboat extends GameObject implements Repair {

}