abstract class GameObject {
    private id: number;
    public positionX: number;
    public positionY: number;
    public maxHp: number;
    public currentHp: number;

    constructor (id: number, positionX: number, positionY: number, maxHp: number, currentHp: number) {
            this.id = id;
            this.positionX = positionX;
            this.positionY = positionY;
            this.maxHp = maxHp;
            this.currentHp = currentHp;

        }

        public get hp(): string {
            return this.currentHp + "/" + this.maxHp
        }

        public get position(): string {
            return this.positionX + ", " + this.positionY
        }
   
}

export { GameObject }