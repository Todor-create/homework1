enum ShipType {
    CORVETTE = "corvette",
    FRIGATE = "frigate",
    DESTROYER = "destoyer",
    BATTLECRUISER = "battlecruiser"
}

export { ShipType }