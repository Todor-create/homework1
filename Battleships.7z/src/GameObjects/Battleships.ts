import { Attack } from "../Interface/Attack";
import { GameObject } from "./GameObject"
import { ShipType } from "./ShipTypes";

class Battleship extends GameObject implements Attack {
    public type: ShipType;
    public armor: number;
    public speed: number;
    public exp: number;
    public lvl: number;
    public dmg: number;

    constructor (type: ShipType, id: number, positionX: number, positionY: number, maxHp: number, currentHp: number, dmg: number, armor: number, speed: number, exp: number, lvl: number,) {
        super (id, positionX, positionY, currentHp, maxHp)
        this.type = type;
        this.armor = armor;
        this.speed = speed;
        this.exp = exp;
        this.lvl = lvl;
        this.dmg = dmg;
       
    }

    public attack(target:GameObject): void {
        target.currentHp -= this.dmg
    }

}



export { Battleship }